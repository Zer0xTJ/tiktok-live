from flask import redirect, request, Flask, render_template
from login_system import login, reg

app = Flask("Login System")


@app.route('/', methods=['get', 'post'])
def index():
    error = False
    if (request.method == 'POST'):
        username = request.form.get('username')
        password = request.form.get('password')
        if (login(username, password)):
            return "You logged in!"
        else:
            error = True
    return render_template("index.html", error=error)


@app.route('/reg', methods=['get', 'post'])
def signup():
    error = False
    if (request.method == 'POST'):
        username = request.form.get('username')
        password = request.form.get('password')
        if (reg(username, password)):
            return redirect('/')
        else:
            error = True
    return render_template("reg.html", error=error)


app.run(debug=True)
