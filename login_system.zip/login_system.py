# make a login system for multiple users
# create users in a list of dictionaries
# make a function for login that
# has 2 params (username, and pasword)

# create a functon for register new user

users = [
    {
        "username": "zer0xtj",
        "password": "123",
    },
    {
        "username": "amd4",
        "password": "1234",
    },
]

# should return true if user exists
# and fals if user not exists


def login(username, password):
    # loop on all users
    for user in users:
        if user['username'] == username and user['password'] == password:
            return True
    return False


def reg(username, password):
    # check if user exists
    for user in users:
        # user alreayd exists
        if user['username'] == username:
            print("User already exists!")
            return False
    # No users found for username
    users.append({
        "username": username,
        "password": password
    })
    print("register done!")
    return True
